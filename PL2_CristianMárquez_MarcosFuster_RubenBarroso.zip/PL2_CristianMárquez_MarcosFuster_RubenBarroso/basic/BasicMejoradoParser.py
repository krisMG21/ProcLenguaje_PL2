# Generated from BasicMejorado.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,39,211,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,1,0,1,0,4,0,37,8,0,11,0,12,0,38,5,
        0,41,8,0,10,0,12,0,44,9,0,1,0,3,0,47,8,0,1,0,1,0,1,1,1,1,1,1,1,1,
        1,1,1,1,1,1,1,1,1,1,3,1,60,8,1,1,2,1,2,1,2,1,2,1,2,1,3,1,3,1,3,1,
        3,1,4,1,4,1,4,1,5,1,5,1,5,1,5,1,6,1,6,1,6,1,6,1,6,1,6,1,6,5,6,85,
        8,6,10,6,12,6,88,9,6,1,6,1,6,1,6,1,6,1,6,5,6,95,8,6,10,6,12,6,98,
        9,6,3,6,100,8,6,1,6,1,6,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,
        5,7,114,8,7,10,7,12,7,117,9,7,1,7,1,7,1,8,1,8,1,8,1,8,1,8,1,8,5,
        8,127,8,8,10,8,12,8,130,9,8,1,8,1,8,1,9,1,9,1,9,1,9,1,9,5,9,139,
        8,9,10,9,12,9,142,9,9,1,9,1,9,1,9,1,10,1,10,1,11,1,11,1,11,1,11,
        1,11,1,11,1,11,1,11,3,11,157,8,11,1,11,1,11,1,11,1,11,5,11,163,8,
        11,10,11,12,11,166,9,11,1,12,1,12,1,13,1,13,1,14,1,14,1,14,1,14,
        1,14,1,14,1,14,1,14,1,14,3,14,181,8,14,1,14,1,14,1,14,1,14,5,14,
        187,8,14,10,14,12,14,190,9,14,1,15,1,15,1,16,1,16,1,16,1,16,1,16,
        1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,3,16,209,8,16,
        1,16,0,2,22,28,17,0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,32,
        0,4,1,0,26,27,1,0,13,14,1,0,1,5,2,0,8,11,30,30,220,0,42,1,0,0,0,
        2,59,1,0,0,0,4,61,1,0,0,0,6,66,1,0,0,0,8,70,1,0,0,0,10,73,1,0,0,
        0,12,77,1,0,0,0,14,103,1,0,0,0,16,120,1,0,0,0,18,133,1,0,0,0,20,
        146,1,0,0,0,22,156,1,0,0,0,24,167,1,0,0,0,26,169,1,0,0,0,28,180,
        1,0,0,0,30,191,1,0,0,0,32,208,1,0,0,0,34,36,3,2,1,0,35,37,5,37,0,
        0,36,35,1,0,0,0,37,38,1,0,0,0,38,36,1,0,0,0,38,39,1,0,0,0,39,41,
        1,0,0,0,40,34,1,0,0,0,41,44,1,0,0,0,42,40,1,0,0,0,42,43,1,0,0,0,
        43,46,1,0,0,0,44,42,1,0,0,0,45,47,3,2,1,0,46,45,1,0,0,0,46,47,1,
        0,0,0,47,48,1,0,0,0,48,49,5,0,0,1,49,1,1,0,0,0,50,60,3,4,2,0,51,
        60,3,6,3,0,52,60,3,8,4,0,53,60,3,10,5,0,54,60,3,12,6,0,55,60,3,14,
        7,0,56,60,3,16,8,0,57,60,3,18,9,0,58,60,3,20,10,0,59,50,1,0,0,0,
        59,51,1,0,0,0,59,52,1,0,0,0,59,53,1,0,0,0,59,54,1,0,0,0,59,55,1,
        0,0,0,59,56,1,0,0,0,59,57,1,0,0,0,59,58,1,0,0,0,60,3,1,0,0,0,61,
        62,5,15,0,0,62,63,5,34,0,0,63,64,5,1,0,0,64,65,3,28,14,0,65,5,1,
        0,0,0,66,67,5,34,0,0,67,68,5,1,0,0,68,69,3,28,14,0,69,7,1,0,0,0,
        70,71,5,16,0,0,71,72,3,28,14,0,72,9,1,0,0,0,73,74,5,17,0,0,74,75,
        5,36,0,0,75,76,5,34,0,0,76,11,1,0,0,0,77,78,5,18,0,0,78,79,3,22,
        11,0,79,80,5,29,0,0,80,86,5,37,0,0,81,82,3,2,1,0,82,83,5,37,0,0,
        83,85,1,0,0,0,84,81,1,0,0,0,85,88,1,0,0,0,86,84,1,0,0,0,86,87,1,
        0,0,0,87,99,1,0,0,0,88,86,1,0,0,0,89,90,5,19,0,0,90,96,5,37,0,0,
        91,92,3,2,1,0,92,93,5,37,0,0,93,95,1,0,0,0,94,91,1,0,0,0,95,98,1,
        0,0,0,96,94,1,0,0,0,96,97,1,0,0,0,97,100,1,0,0,0,98,96,1,0,0,0,99,
        89,1,0,0,0,99,100,1,0,0,0,100,101,1,0,0,0,101,102,5,28,0,0,102,13,
        1,0,0,0,103,104,5,20,0,0,104,105,5,34,0,0,105,106,5,1,0,0,106,107,
        3,28,14,0,107,108,5,21,0,0,108,109,3,28,14,0,109,115,5,37,0,0,110,
        111,3,2,1,0,111,112,5,37,0,0,112,114,1,0,0,0,113,110,1,0,0,0,114,
        117,1,0,0,0,115,113,1,0,0,0,115,116,1,0,0,0,116,118,1,0,0,0,117,
        115,1,0,0,0,118,119,5,22,0,0,119,15,1,0,0,0,120,121,5,23,0,0,121,
        122,3,22,11,0,122,128,5,37,0,0,123,124,3,2,1,0,124,125,5,37,0,0,
        125,127,1,0,0,0,126,123,1,0,0,0,127,130,1,0,0,0,128,126,1,0,0,0,
        128,129,1,0,0,0,129,131,1,0,0,0,130,128,1,0,0,0,131,132,5,28,0,0,
        132,17,1,0,0,0,133,134,5,24,0,0,134,140,5,37,0,0,135,136,3,2,1,0,
        136,137,5,37,0,0,137,139,1,0,0,0,138,135,1,0,0,0,139,142,1,0,0,0,
        140,138,1,0,0,0,140,141,1,0,0,0,141,143,1,0,0,0,142,140,1,0,0,0,
        143,144,5,25,0,0,144,145,3,22,11,0,145,19,1,0,0,0,146,147,7,0,0,
        0,147,21,1,0,0,0,148,149,6,11,-1,0,149,150,3,28,14,0,150,151,3,26,
        13,0,151,152,3,28,14,0,152,157,1,0,0,0,153,154,5,12,0,0,154,157,
        3,22,11,3,155,157,3,28,14,0,156,148,1,0,0,0,156,153,1,0,0,0,156,
        155,1,0,0,0,157,164,1,0,0,0,158,159,10,2,0,0,159,160,3,24,12,0,160,
        161,3,22,11,3,161,163,1,0,0,0,162,158,1,0,0,0,163,166,1,0,0,0,164,
        162,1,0,0,0,164,165,1,0,0,0,165,23,1,0,0,0,166,164,1,0,0,0,167,168,
        7,1,0,0,168,25,1,0,0,0,169,170,7,2,0,0,170,27,1,0,0,0,171,172,6,
        14,-1,0,172,173,5,6,0,0,173,174,3,28,14,0,174,175,5,7,0,0,175,181,
        1,0,0,0,176,181,3,32,16,0,177,181,5,35,0,0,178,181,5,36,0,0,179,
        181,5,34,0,0,180,171,1,0,0,0,180,176,1,0,0,0,180,177,1,0,0,0,180,
        178,1,0,0,0,180,179,1,0,0,0,181,188,1,0,0,0,182,183,10,6,0,0,183,
        184,3,30,15,0,184,185,3,28,14,7,185,187,1,0,0,0,186,182,1,0,0,0,
        187,190,1,0,0,0,188,186,1,0,0,0,188,189,1,0,0,0,189,29,1,0,0,0,190,
        188,1,0,0,0,191,192,7,3,0,0,192,31,1,0,0,0,193,194,5,31,0,0,194,
        195,5,6,0,0,195,196,3,28,14,0,196,197,5,7,0,0,197,209,1,0,0,0,198,
        199,5,32,0,0,199,200,5,6,0,0,200,201,3,28,14,0,201,202,5,7,0,0,202,
        209,1,0,0,0,203,204,5,33,0,0,204,205,5,6,0,0,205,206,3,28,14,0,206,
        207,5,7,0,0,207,209,1,0,0,0,208,193,1,0,0,0,208,198,1,0,0,0,208,
        203,1,0,0,0,209,33,1,0,0,0,15,38,42,46,59,86,96,99,115,128,140,156,
        164,180,188,208
    ]

class BasicMejoradoParser ( Parser ):

    grammarFileName = "BasicMejorado.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'='", "'<'", "'>'", "'<='", "'>='", "'('", 
                     "')'", "'+'", "'-'", "'*'", "'/'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "NOT", "AND", "OR", "LET", "PRINT", "INPUT", "IF", 
                      "ELSE", "FOR", "TO", "NEXT", "WHILE", "REPEAT", "UNTIL", 
                      "CONTINUE", "EXIT", "END", "THEN", "MOD", "VAL", "LEN", 
                      "ISNAN", "ID", "NUMBER", "STRING_LITERAL", "NEWLINE", 
                      "COMMENT", "WS" ]

    RULE_program = 0
    RULE_statement = 1
    RULE_letStmt = 2
    RULE_opStmt = 3
    RULE_printStmt = 4
    RULE_inputStmt = 5
    RULE_ifStmt = 6
    RULE_forStmt = 7
    RULE_whileStmt = 8
    RULE_repeatStmt = 9
    RULE_keyStmt = 10
    RULE_condition = 11
    RULE_logicalOp = 12
    RULE_comparisonOp = 13
    RULE_expression = 14
    RULE_op = 15
    RULE_functionCall = 16

    ruleNames =  [ "program", "statement", "letStmt", "opStmt", "printStmt", 
                   "inputStmt", "ifStmt", "forStmt", "whileStmt", "repeatStmt", 
                   "keyStmt", "condition", "logicalOp", "comparisonOp", 
                   "expression", "op", "functionCall" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    T__10=11
    NOT=12
    AND=13
    OR=14
    LET=15
    PRINT=16
    INPUT=17
    IF=18
    ELSE=19
    FOR=20
    TO=21
    NEXT=22
    WHILE=23
    REPEAT=24
    UNTIL=25
    CONTINUE=26
    EXIT=27
    END=28
    THEN=29
    MOD=30
    VAL=31
    LEN=32
    ISNAN=33
    ID=34
    NUMBER=35
    STRING_LITERAL=36
    NEWLINE=37
    COMMENT=38
    WS=39

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgramContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(BasicMejoradoParser.EOF, 0)

        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(BasicMejoradoParser.StatementContext)
            else:
                return self.getTypedRuleContext(BasicMejoradoParser.StatementContext,i)


        def NEWLINE(self, i:int=None):
            if i is None:
                return self.getTokens(BasicMejoradoParser.NEWLINE)
            else:
                return self.getToken(BasicMejoradoParser.NEWLINE, i)

        def getRuleIndex(self):
            return BasicMejoradoParser.RULE_program

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterProgram" ):
                listener.enterProgram(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitProgram" ):
                listener.exitProgram(self)




    def program(self):

        localctx = BasicMejoradoParser.ProgramContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_program)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 42
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,1,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 34
                    self.statement()
                    self.state = 36 
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    while True:
                        self.state = 35
                        self.match(BasicMejoradoParser.NEWLINE)
                        self.state = 38 
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)
                        if not (_la==37):
                            break
             
                self.state = 44
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,1,self._ctx)

            self.state = 46
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 17407901696) != 0):
                self.state = 45
                self.statement()


            self.state = 48
            self.match(BasicMejoradoParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def letStmt(self):
            return self.getTypedRuleContext(BasicMejoradoParser.LetStmtContext,0)


        def opStmt(self):
            return self.getTypedRuleContext(BasicMejoradoParser.OpStmtContext,0)


        def printStmt(self):
            return self.getTypedRuleContext(BasicMejoradoParser.PrintStmtContext,0)


        def inputStmt(self):
            return self.getTypedRuleContext(BasicMejoradoParser.InputStmtContext,0)


        def ifStmt(self):
            return self.getTypedRuleContext(BasicMejoradoParser.IfStmtContext,0)


        def forStmt(self):
            return self.getTypedRuleContext(BasicMejoradoParser.ForStmtContext,0)


        def whileStmt(self):
            return self.getTypedRuleContext(BasicMejoradoParser.WhileStmtContext,0)


        def repeatStmt(self):
            return self.getTypedRuleContext(BasicMejoradoParser.RepeatStmtContext,0)


        def keyStmt(self):
            return self.getTypedRuleContext(BasicMejoradoParser.KeyStmtContext,0)


        def getRuleIndex(self):
            return BasicMejoradoParser.RULE_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStatement" ):
                listener.enterStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStatement" ):
                listener.exitStatement(self)




    def statement(self):

        localctx = BasicMejoradoParser.StatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_statement)
        try:
            self.state = 59
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [15]:
                self.enterOuterAlt(localctx, 1)
                self.state = 50
                self.letStmt()
                pass
            elif token in [34]:
                self.enterOuterAlt(localctx, 2)
                self.state = 51
                self.opStmt()
                pass
            elif token in [16]:
                self.enterOuterAlt(localctx, 3)
                self.state = 52
                self.printStmt()
                pass
            elif token in [17]:
                self.enterOuterAlt(localctx, 4)
                self.state = 53
                self.inputStmt()
                pass
            elif token in [18]:
                self.enterOuterAlt(localctx, 5)
                self.state = 54
                self.ifStmt()
                pass
            elif token in [20]:
                self.enterOuterAlt(localctx, 6)
                self.state = 55
                self.forStmt()
                pass
            elif token in [23]:
                self.enterOuterAlt(localctx, 7)
                self.state = 56
                self.whileStmt()
                pass
            elif token in [24]:
                self.enterOuterAlt(localctx, 8)
                self.state = 57
                self.repeatStmt()
                pass
            elif token in [26, 27]:
                self.enterOuterAlt(localctx, 9)
                self.state = 58
                self.keyStmt()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LetStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LET(self):
            return self.getToken(BasicMejoradoParser.LET, 0)

        def ID(self):
            return self.getToken(BasicMejoradoParser.ID, 0)

        def expression(self):
            return self.getTypedRuleContext(BasicMejoradoParser.ExpressionContext,0)


        def getRuleIndex(self):
            return BasicMejoradoParser.RULE_letStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLetStmt" ):
                listener.enterLetStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLetStmt" ):
                listener.exitLetStmt(self)




    def letStmt(self):

        localctx = BasicMejoradoParser.LetStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_letStmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 61
            self.match(BasicMejoradoParser.LET)
            self.state = 62
            self.match(BasicMejoradoParser.ID)
            self.state = 63
            self.match(BasicMejoradoParser.T__0)
            self.state = 64
            self.expression(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class OpStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(BasicMejoradoParser.ID, 0)

        def expression(self):
            return self.getTypedRuleContext(BasicMejoradoParser.ExpressionContext,0)


        def getRuleIndex(self):
            return BasicMejoradoParser.RULE_opStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOpStmt" ):
                listener.enterOpStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOpStmt" ):
                listener.exitOpStmt(self)




    def opStmt(self):

        localctx = BasicMejoradoParser.OpStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_opStmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 66
            self.match(BasicMejoradoParser.ID)
            self.state = 67
            self.match(BasicMejoradoParser.T__0)
            self.state = 68
            self.expression(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PrintStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def PRINT(self):
            return self.getToken(BasicMejoradoParser.PRINT, 0)

        def expression(self):
            return self.getTypedRuleContext(BasicMejoradoParser.ExpressionContext,0)


        def getRuleIndex(self):
            return BasicMejoradoParser.RULE_printStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrintStmt" ):
                listener.enterPrintStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrintStmt" ):
                listener.exitPrintStmt(self)




    def printStmt(self):

        localctx = BasicMejoradoParser.PrintStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_printStmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 70
            self.match(BasicMejoradoParser.PRINT)
            self.state = 71
            self.expression(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InputStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INPUT(self):
            return self.getToken(BasicMejoradoParser.INPUT, 0)

        def STRING_LITERAL(self):
            return self.getToken(BasicMejoradoParser.STRING_LITERAL, 0)

        def ID(self):
            return self.getToken(BasicMejoradoParser.ID, 0)

        def getRuleIndex(self):
            return BasicMejoradoParser.RULE_inputStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInputStmt" ):
                listener.enterInputStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInputStmt" ):
                listener.exitInputStmt(self)




    def inputStmt(self):

        localctx = BasicMejoradoParser.InputStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_inputStmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 73
            self.match(BasicMejoradoParser.INPUT)
            self.state = 74
            self.match(BasicMejoradoParser.STRING_LITERAL)
            self.state = 75
            self.match(BasicMejoradoParser.ID)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IfStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IF(self):
            return self.getToken(BasicMejoradoParser.IF, 0)

        def condition(self):
            return self.getTypedRuleContext(BasicMejoradoParser.ConditionContext,0)


        def THEN(self):
            return self.getToken(BasicMejoradoParser.THEN, 0)

        def NEWLINE(self, i:int=None):
            if i is None:
                return self.getTokens(BasicMejoradoParser.NEWLINE)
            else:
                return self.getToken(BasicMejoradoParser.NEWLINE, i)

        def END(self):
            return self.getToken(BasicMejoradoParser.END, 0)

        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(BasicMejoradoParser.StatementContext)
            else:
                return self.getTypedRuleContext(BasicMejoradoParser.StatementContext,i)


        def ELSE(self):
            return self.getToken(BasicMejoradoParser.ELSE, 0)

        def getRuleIndex(self):
            return BasicMejoradoParser.RULE_ifStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIfStmt" ):
                listener.enterIfStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIfStmt" ):
                listener.exitIfStmt(self)




    def ifStmt(self):

        localctx = BasicMejoradoParser.IfStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_ifStmt)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 77
            self.match(BasicMejoradoParser.IF)
            self.state = 78
            self.condition(0)
            self.state = 79
            self.match(BasicMejoradoParser.THEN)
            self.state = 80
            self.match(BasicMejoradoParser.NEWLINE)
            self.state = 86
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 17407901696) != 0):
                self.state = 81
                self.statement()
                self.state = 82
                self.match(BasicMejoradoParser.NEWLINE)
                self.state = 88
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 99
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==19:
                self.state = 89
                self.match(BasicMejoradoParser.ELSE)
                self.state = 90
                self.match(BasicMejoradoParser.NEWLINE)
                self.state = 96
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while (((_la) & ~0x3f) == 0 and ((1 << _la) & 17407901696) != 0):
                    self.state = 91
                    self.statement()
                    self.state = 92
                    self.match(BasicMejoradoParser.NEWLINE)
                    self.state = 98
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)



            self.state = 101
            self.match(BasicMejoradoParser.END)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ForStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def FOR(self):
            return self.getToken(BasicMejoradoParser.FOR, 0)

        def ID(self):
            return self.getToken(BasicMejoradoParser.ID, 0)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(BasicMejoradoParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(BasicMejoradoParser.ExpressionContext,i)


        def TO(self):
            return self.getToken(BasicMejoradoParser.TO, 0)

        def NEWLINE(self, i:int=None):
            if i is None:
                return self.getTokens(BasicMejoradoParser.NEWLINE)
            else:
                return self.getToken(BasicMejoradoParser.NEWLINE, i)

        def NEXT(self):
            return self.getToken(BasicMejoradoParser.NEXT, 0)

        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(BasicMejoradoParser.StatementContext)
            else:
                return self.getTypedRuleContext(BasicMejoradoParser.StatementContext,i)


        def getRuleIndex(self):
            return BasicMejoradoParser.RULE_forStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterForStmt" ):
                listener.enterForStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitForStmt" ):
                listener.exitForStmt(self)




    def forStmt(self):

        localctx = BasicMejoradoParser.ForStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_forStmt)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 103
            self.match(BasicMejoradoParser.FOR)
            self.state = 104
            self.match(BasicMejoradoParser.ID)
            self.state = 105
            self.match(BasicMejoradoParser.T__0)
            self.state = 106
            self.expression(0)
            self.state = 107
            self.match(BasicMejoradoParser.TO)
            self.state = 108
            self.expression(0)
            self.state = 109
            self.match(BasicMejoradoParser.NEWLINE)
            self.state = 115
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 17407901696) != 0):
                self.state = 110
                self.statement()
                self.state = 111
                self.match(BasicMejoradoParser.NEWLINE)
                self.state = 117
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 118
            self.match(BasicMejoradoParser.NEXT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class WhileStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def WHILE(self):
            return self.getToken(BasicMejoradoParser.WHILE, 0)

        def condition(self):
            return self.getTypedRuleContext(BasicMejoradoParser.ConditionContext,0)


        def NEWLINE(self, i:int=None):
            if i is None:
                return self.getTokens(BasicMejoradoParser.NEWLINE)
            else:
                return self.getToken(BasicMejoradoParser.NEWLINE, i)

        def END(self):
            return self.getToken(BasicMejoradoParser.END, 0)

        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(BasicMejoradoParser.StatementContext)
            else:
                return self.getTypedRuleContext(BasicMejoradoParser.StatementContext,i)


        def getRuleIndex(self):
            return BasicMejoradoParser.RULE_whileStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterWhileStmt" ):
                listener.enterWhileStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitWhileStmt" ):
                listener.exitWhileStmt(self)




    def whileStmt(self):

        localctx = BasicMejoradoParser.WhileStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_whileStmt)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 120
            self.match(BasicMejoradoParser.WHILE)
            self.state = 121
            self.condition(0)
            self.state = 122
            self.match(BasicMejoradoParser.NEWLINE)
            self.state = 128
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 17407901696) != 0):
                self.state = 123
                self.statement()
                self.state = 124
                self.match(BasicMejoradoParser.NEWLINE)
                self.state = 130
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 131
            self.match(BasicMejoradoParser.END)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RepeatStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def REPEAT(self):
            return self.getToken(BasicMejoradoParser.REPEAT, 0)

        def NEWLINE(self, i:int=None):
            if i is None:
                return self.getTokens(BasicMejoradoParser.NEWLINE)
            else:
                return self.getToken(BasicMejoradoParser.NEWLINE, i)

        def UNTIL(self):
            return self.getToken(BasicMejoradoParser.UNTIL, 0)

        def condition(self):
            return self.getTypedRuleContext(BasicMejoradoParser.ConditionContext,0)


        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(BasicMejoradoParser.StatementContext)
            else:
                return self.getTypedRuleContext(BasicMejoradoParser.StatementContext,i)


        def getRuleIndex(self):
            return BasicMejoradoParser.RULE_repeatStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRepeatStmt" ):
                listener.enterRepeatStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRepeatStmt" ):
                listener.exitRepeatStmt(self)




    def repeatStmt(self):

        localctx = BasicMejoradoParser.RepeatStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_repeatStmt)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 133
            self.match(BasicMejoradoParser.REPEAT)
            self.state = 134
            self.match(BasicMejoradoParser.NEWLINE)
            self.state = 140
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 17407901696) != 0):
                self.state = 135
                self.statement()
                self.state = 136
                self.match(BasicMejoradoParser.NEWLINE)
                self.state = 142
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 143
            self.match(BasicMejoradoParser.UNTIL)
            self.state = 144
            self.condition(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class KeyStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CONTINUE(self):
            return self.getToken(BasicMejoradoParser.CONTINUE, 0)

        def EXIT(self):
            return self.getToken(BasicMejoradoParser.EXIT, 0)

        def getRuleIndex(self):
            return BasicMejoradoParser.RULE_keyStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKeyStmt" ):
                listener.enterKeyStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKeyStmt" ):
                listener.exitKeyStmt(self)




    def keyStmt(self):

        localctx = BasicMejoradoParser.KeyStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_keyStmt)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 146
            _la = self._input.LA(1)
            if not(_la==26 or _la==27):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConditionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(BasicMejoradoParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(BasicMejoradoParser.ExpressionContext,i)


        def comparisonOp(self):
            return self.getTypedRuleContext(BasicMejoradoParser.ComparisonOpContext,0)


        def NOT(self):
            return self.getToken(BasicMejoradoParser.NOT, 0)

        def condition(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(BasicMejoradoParser.ConditionContext)
            else:
                return self.getTypedRuleContext(BasicMejoradoParser.ConditionContext,i)


        def logicalOp(self):
            return self.getTypedRuleContext(BasicMejoradoParser.LogicalOpContext,0)


        def getRuleIndex(self):
            return BasicMejoradoParser.RULE_condition

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCondition" ):
                listener.enterCondition(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCondition" ):
                listener.exitCondition(self)



    def condition(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = BasicMejoradoParser.ConditionContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 22
        self.enterRecursionRule(localctx, 22, self.RULE_condition, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 156
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,10,self._ctx)
            if la_ == 1:
                self.state = 149
                self.expression(0)
                self.state = 150
                self.comparisonOp()
                self.state = 151
                self.expression(0)
                pass

            elif la_ == 2:
                self.state = 153
                self.match(BasicMejoradoParser.NOT)
                self.state = 154
                self.condition(3)
                pass

            elif la_ == 3:
                self.state = 155
                self.expression(0)
                pass


            self._ctx.stop = self._input.LT(-1)
            self.state = 164
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,11,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    localctx = BasicMejoradoParser.ConditionContext(self, _parentctx, _parentState)
                    self.pushNewRecursionContext(localctx, _startState, self.RULE_condition)
                    self.state = 158
                    if not self.precpred(self._ctx, 2):
                        from antlr4.error.Errors import FailedPredicateException
                        raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                    self.state = 159
                    self.logicalOp()
                    self.state = 160
                    self.condition(3) 
                self.state = 166
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,11,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class LogicalOpContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def AND(self):
            return self.getToken(BasicMejoradoParser.AND, 0)

        def OR(self):
            return self.getToken(BasicMejoradoParser.OR, 0)

        def getRuleIndex(self):
            return BasicMejoradoParser.RULE_logicalOp

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLogicalOp" ):
                listener.enterLogicalOp(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLogicalOp" ):
                listener.exitLogicalOp(self)




    def logicalOp(self):

        localctx = BasicMejoradoParser.LogicalOpContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_logicalOp)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 167
            _la = self._input.LA(1)
            if not(_la==13 or _la==14):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ComparisonOpContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return BasicMejoradoParser.RULE_comparisonOp

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComparisonOp" ):
                listener.enterComparisonOp(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComparisonOp" ):
                listener.exitComparisonOp(self)




    def comparisonOp(self):

        localctx = BasicMejoradoParser.ComparisonOpContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_comparisonOp)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 169
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 62) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(BasicMejoradoParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(BasicMejoradoParser.ExpressionContext,i)


        def functionCall(self):
            return self.getTypedRuleContext(BasicMejoradoParser.FunctionCallContext,0)


        def NUMBER(self):
            return self.getToken(BasicMejoradoParser.NUMBER, 0)

        def STRING_LITERAL(self):
            return self.getToken(BasicMejoradoParser.STRING_LITERAL, 0)

        def ID(self):
            return self.getToken(BasicMejoradoParser.ID, 0)

        def op(self):
            return self.getTypedRuleContext(BasicMejoradoParser.OpContext,0)


        def getRuleIndex(self):
            return BasicMejoradoParser.RULE_expression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpression" ):
                listener.enterExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpression" ):
                listener.exitExpression(self)



    def expression(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = BasicMejoradoParser.ExpressionContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 28
        self.enterRecursionRule(localctx, 28, self.RULE_expression, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 180
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [6]:
                self.state = 172
                self.match(BasicMejoradoParser.T__5)
                self.state = 173
                self.expression(0)
                self.state = 174
                self.match(BasicMejoradoParser.T__6)
                pass
            elif token in [31, 32, 33]:
                self.state = 176
                self.functionCall()
                pass
            elif token in [35]:
                self.state = 177
                self.match(BasicMejoradoParser.NUMBER)
                pass
            elif token in [36]:
                self.state = 178
                self.match(BasicMejoradoParser.STRING_LITERAL)
                pass
            elif token in [34]:
                self.state = 179
                self.match(BasicMejoradoParser.ID)
                pass
            else:
                raise NoViableAltException(self)

            self._ctx.stop = self._input.LT(-1)
            self.state = 188
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,13,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    localctx = BasicMejoradoParser.ExpressionContext(self, _parentctx, _parentState)
                    self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                    self.state = 182
                    if not self.precpred(self._ctx, 6):
                        from antlr4.error.Errors import FailedPredicateException
                        raise FailedPredicateException(self, "self.precpred(self._ctx, 6)")
                    self.state = 183
                    self.op()
                    self.state = 184
                    self.expression(7) 
                self.state = 190
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,13,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class OpContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def MOD(self):
            return self.getToken(BasicMejoradoParser.MOD, 0)

        def getRuleIndex(self):
            return BasicMejoradoParser.RULE_op

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOp" ):
                listener.enterOp(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOp" ):
                listener.exitOp(self)




    def op(self):

        localctx = BasicMejoradoParser.OpContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_op)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 191
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 1073745664) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FunctionCallContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def VAL(self):
            return self.getToken(BasicMejoradoParser.VAL, 0)

        def expression(self):
            return self.getTypedRuleContext(BasicMejoradoParser.ExpressionContext,0)


        def LEN(self):
            return self.getToken(BasicMejoradoParser.LEN, 0)

        def ISNAN(self):
            return self.getToken(BasicMejoradoParser.ISNAN, 0)

        def getRuleIndex(self):
            return BasicMejoradoParser.RULE_functionCall

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFunctionCall" ):
                listener.enterFunctionCall(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFunctionCall" ):
                listener.exitFunctionCall(self)




    def functionCall(self):

        localctx = BasicMejoradoParser.FunctionCallContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_functionCall)
        try:
            self.state = 208
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [31]:
                self.enterOuterAlt(localctx, 1)
                self.state = 193
                self.match(BasicMejoradoParser.VAL)
                self.state = 194
                self.match(BasicMejoradoParser.T__5)
                self.state = 195
                self.expression(0)
                self.state = 196
                self.match(BasicMejoradoParser.T__6)
                pass
            elif token in [32]:
                self.enterOuterAlt(localctx, 2)
                self.state = 198
                self.match(BasicMejoradoParser.LEN)
                self.state = 199
                self.match(BasicMejoradoParser.T__5)
                self.state = 200
                self.expression(0)
                self.state = 201
                self.match(BasicMejoradoParser.T__6)
                pass
            elif token in [33]:
                self.enterOuterAlt(localctx, 3)
                self.state = 203
                self.match(BasicMejoradoParser.ISNAN)
                self.state = 204
                self.match(BasicMejoradoParser.T__5)
                self.state = 205
                self.expression(0)
                self.state = 206
                self.match(BasicMejoradoParser.T__6)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[11] = self.condition_sempred
        self._predicates[14] = self.expression_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def condition_sempred(self, localctx:ConditionContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 2)
         

    def expression_sempred(self, localctx:ExpressionContext, predIndex:int):
            if predIndex == 1:
                return self.precpred(self._ctx, 6)
         




