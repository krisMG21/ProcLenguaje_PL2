# Generated from Basic.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,36,190,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,1,0,1,0,4,0,33,8,0,11,0,12,0,34,5,0,37,8,0,10,0,12,0,40,
        9,0,1,0,3,0,43,8,0,1,0,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,3,
        1,56,8,1,1,2,1,2,1,2,1,2,1,2,1,3,1,3,1,3,1,3,1,4,1,4,1,4,1,5,1,5,
        1,5,1,5,1,6,1,6,1,6,1,6,1,6,1,6,1,6,5,6,81,8,6,10,6,12,6,84,9,6,
        1,6,1,6,1,6,1,6,1,6,5,6,91,8,6,10,6,12,6,94,9,6,3,6,96,8,6,1,6,1,
        6,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,5,7,110,8,7,10,7,12,7,
        113,9,7,1,7,1,7,1,8,1,8,1,8,1,8,1,8,1,8,5,8,123,8,8,10,8,12,8,126,
        9,8,1,8,1,8,1,9,1,9,1,9,1,9,1,9,5,9,135,8,9,10,9,12,9,138,9,9,1,
        9,1,9,1,9,1,10,1,10,1,11,1,11,1,11,1,11,1,11,3,11,150,8,11,1,12,
        1,12,1,13,1,13,1,13,1,13,1,13,1,13,1,13,1,13,1,13,3,13,163,8,13,
        1,13,1,13,1,13,5,13,168,8,13,10,13,12,13,171,9,13,1,14,1,14,1,14,
        1,14,1,14,1,14,1,14,1,14,1,14,1,14,1,14,1,14,1,14,1,14,1,14,3,14,
        188,8,14,1,14,0,1,26,15,0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,
        0,3,1,0,23,24,1,0,1,5,2,0,6,9,27,27,199,0,38,1,0,0,0,2,55,1,0,0,
        0,4,57,1,0,0,0,6,62,1,0,0,0,8,66,1,0,0,0,10,69,1,0,0,0,12,73,1,0,
        0,0,14,99,1,0,0,0,16,116,1,0,0,0,18,129,1,0,0,0,20,142,1,0,0,0,22,
        149,1,0,0,0,24,151,1,0,0,0,26,162,1,0,0,0,28,187,1,0,0,0,30,32,3,
        2,1,0,31,33,5,34,0,0,32,31,1,0,0,0,33,34,1,0,0,0,34,32,1,0,0,0,34,
        35,1,0,0,0,35,37,1,0,0,0,36,30,1,0,0,0,37,40,1,0,0,0,38,36,1,0,0,
        0,38,39,1,0,0,0,39,42,1,0,0,0,40,38,1,0,0,0,41,43,3,2,1,0,42,41,
        1,0,0,0,42,43,1,0,0,0,43,44,1,0,0,0,44,45,5,0,0,1,45,1,1,0,0,0,46,
        56,3,4,2,0,47,56,3,6,3,0,48,56,3,8,4,0,49,56,3,10,5,0,50,56,3,12,
        6,0,51,56,3,14,7,0,52,56,3,16,8,0,53,56,3,18,9,0,54,56,3,20,10,0,
        55,46,1,0,0,0,55,47,1,0,0,0,55,48,1,0,0,0,55,49,1,0,0,0,55,50,1,
        0,0,0,55,51,1,0,0,0,55,52,1,0,0,0,55,53,1,0,0,0,55,54,1,0,0,0,56,
        3,1,0,0,0,57,58,5,12,0,0,58,59,5,31,0,0,59,60,5,1,0,0,60,61,3,26,
        13,0,61,5,1,0,0,0,62,63,5,31,0,0,63,64,5,1,0,0,64,65,3,26,13,0,65,
        7,1,0,0,0,66,67,5,13,0,0,67,68,3,26,13,0,68,9,1,0,0,0,69,70,5,14,
        0,0,70,71,5,33,0,0,71,72,5,31,0,0,72,11,1,0,0,0,73,74,5,15,0,0,74,
        75,3,22,11,0,75,76,5,26,0,0,76,82,5,34,0,0,77,78,3,2,1,0,78,79,5,
        34,0,0,79,81,1,0,0,0,80,77,1,0,0,0,81,84,1,0,0,0,82,80,1,0,0,0,82,
        83,1,0,0,0,83,95,1,0,0,0,84,82,1,0,0,0,85,86,5,16,0,0,86,92,5,34,
        0,0,87,88,3,2,1,0,88,89,5,34,0,0,89,91,1,0,0,0,90,87,1,0,0,0,91,
        94,1,0,0,0,92,90,1,0,0,0,92,93,1,0,0,0,93,96,1,0,0,0,94,92,1,0,0,
        0,95,85,1,0,0,0,95,96,1,0,0,0,96,97,1,0,0,0,97,98,5,25,0,0,98,13,
        1,0,0,0,99,100,5,17,0,0,100,101,5,31,0,0,101,102,5,1,0,0,102,103,
        3,26,13,0,103,104,5,18,0,0,104,105,3,26,13,0,105,111,5,34,0,0,106,
        107,3,2,1,0,107,108,5,34,0,0,108,110,1,0,0,0,109,106,1,0,0,0,110,
        113,1,0,0,0,111,109,1,0,0,0,111,112,1,0,0,0,112,114,1,0,0,0,113,
        111,1,0,0,0,114,115,5,19,0,0,115,15,1,0,0,0,116,117,5,20,0,0,117,
        118,3,22,11,0,118,124,5,34,0,0,119,120,3,2,1,0,120,121,5,34,0,0,
        121,123,1,0,0,0,122,119,1,0,0,0,123,126,1,0,0,0,124,122,1,0,0,0,
        124,125,1,0,0,0,125,127,1,0,0,0,126,124,1,0,0,0,127,128,5,25,0,0,
        128,17,1,0,0,0,129,130,5,21,0,0,130,136,5,34,0,0,131,132,3,2,1,0,
        132,133,5,34,0,0,133,135,1,0,0,0,134,131,1,0,0,0,135,138,1,0,0,0,
        136,134,1,0,0,0,136,137,1,0,0,0,137,139,1,0,0,0,138,136,1,0,0,0,
        139,140,5,22,0,0,140,141,3,22,11,0,141,19,1,0,0,0,142,143,7,0,0,
        0,143,21,1,0,0,0,144,145,3,26,13,0,145,146,3,24,12,0,146,147,3,26,
        13,0,147,150,1,0,0,0,148,150,3,26,13,0,149,144,1,0,0,0,149,148,1,
        0,0,0,150,23,1,0,0,0,151,152,7,1,0,0,152,25,1,0,0,0,153,154,6,13,
        -1,0,154,155,5,10,0,0,155,156,3,26,13,0,156,157,5,11,0,0,157,163,
        1,0,0,0,158,163,3,28,14,0,159,163,5,32,0,0,160,163,5,33,0,0,161,
        163,5,31,0,0,162,153,1,0,0,0,162,158,1,0,0,0,162,159,1,0,0,0,162,
        160,1,0,0,0,162,161,1,0,0,0,163,169,1,0,0,0,164,165,10,6,0,0,165,
        166,7,2,0,0,166,168,3,26,13,7,167,164,1,0,0,0,168,171,1,0,0,0,169,
        167,1,0,0,0,169,170,1,0,0,0,170,27,1,0,0,0,171,169,1,0,0,0,172,173,
        5,28,0,0,173,174,5,10,0,0,174,175,3,26,13,0,175,176,5,11,0,0,176,
        188,1,0,0,0,177,178,5,29,0,0,178,179,5,10,0,0,179,180,3,26,13,0,
        180,181,5,11,0,0,181,188,1,0,0,0,182,183,5,30,0,0,183,184,5,10,0,
        0,184,185,3,26,13,0,185,186,5,11,0,0,186,188,1,0,0,0,187,172,1,0,
        0,0,187,177,1,0,0,0,187,182,1,0,0,0,188,29,1,0,0,0,14,34,38,42,55,
        82,92,95,111,124,136,149,162,169,187
    ]

class BasicParser ( Parser ):

    grammarFileName = "Basic.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'='", "'<'", "'>'", "'<='", "'>='", "'+'", 
                     "'-'", "'*'", "'/'", "'('", "')'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "LET_KW", "PRINT_KW", "INPUT_KW", "IF_KW", "ELSE_KW", 
                      "FOR_KW", "TO_KW", "NEXT_KW", "WHILE_KW", "REPEAT_KW", 
                      "UNTIL_KW", "CONTINUE_KW", "EXIT_KW", "END_KW", "THEN_KW", 
                      "MOD_KW", "VAL_KW", "LEN_KW", "ISNAN_KW", "ID", "NUMBER", 
                      "STRING_LITERAL", "NEWLINE", "COMMENT", "WS" ]

    RULE_program = 0
    RULE_statement = 1
    RULE_letStmt = 2
    RULE_opStmt = 3
    RULE_printStmt = 4
    RULE_inputStmt = 5
    RULE_ifStmt = 6
    RULE_forStmt = 7
    RULE_whileStmt = 8
    RULE_repeatStmt = 9
    RULE_keyStmt = 10
    RULE_condition = 11
    RULE_comparisonOp = 12
    RULE_expression = 13
    RULE_functionCall = 14

    ruleNames =  [ "program", "statement", "letStmt", "opStmt", "printStmt", 
                   "inputStmt", "ifStmt", "forStmt", "whileStmt", "repeatStmt", 
                   "keyStmt", "condition", "comparisonOp", "expression", 
                   "functionCall" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    T__10=11
    LET_KW=12
    PRINT_KW=13
    INPUT_KW=14
    IF_KW=15
    ELSE_KW=16
    FOR_KW=17
    TO_KW=18
    NEXT_KW=19
    WHILE_KW=20
    REPEAT_KW=21
    UNTIL_KW=22
    CONTINUE_KW=23
    EXIT_KW=24
    END_KW=25
    THEN_KW=26
    MOD_KW=27
    VAL_KW=28
    LEN_KW=29
    ISNAN_KW=30
    ID=31
    NUMBER=32
    STRING_LITERAL=33
    NEWLINE=34
    COMMENT=35
    WS=36

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgramContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(BasicParser.EOF, 0)

        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(BasicParser.StatementContext)
            else:
                return self.getTypedRuleContext(BasicParser.StatementContext,i)


        def NEWLINE(self, i:int=None):
            if i is None:
                return self.getTokens(BasicParser.NEWLINE)
            else:
                return self.getToken(BasicParser.NEWLINE, i)

        def getRuleIndex(self):
            return BasicParser.RULE_program

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterProgram" ):
                listener.enterProgram(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitProgram" ):
                listener.exitProgram(self)




    def program(self):

        localctx = BasicParser.ProgramContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_program)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 38
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,1,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 30
                    self.statement()
                    self.state = 32 
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    while True:
                        self.state = 31
                        self.match(BasicParser.NEWLINE)
                        self.state = 34 
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)
                        if not (_la==34):
                            break
             
                self.state = 40
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,1,self._ctx)

            self.state = 42
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 2175987712) != 0):
                self.state = 41
                self.statement()


            self.state = 44
            self.match(BasicParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def letStmt(self):
            return self.getTypedRuleContext(BasicParser.LetStmtContext,0)


        def opStmt(self):
            return self.getTypedRuleContext(BasicParser.OpStmtContext,0)


        def printStmt(self):
            return self.getTypedRuleContext(BasicParser.PrintStmtContext,0)


        def inputStmt(self):
            return self.getTypedRuleContext(BasicParser.InputStmtContext,0)


        def ifStmt(self):
            return self.getTypedRuleContext(BasicParser.IfStmtContext,0)


        def forStmt(self):
            return self.getTypedRuleContext(BasicParser.ForStmtContext,0)


        def whileStmt(self):
            return self.getTypedRuleContext(BasicParser.WhileStmtContext,0)


        def repeatStmt(self):
            return self.getTypedRuleContext(BasicParser.RepeatStmtContext,0)


        def keyStmt(self):
            return self.getTypedRuleContext(BasicParser.KeyStmtContext,0)


        def getRuleIndex(self):
            return BasicParser.RULE_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStatement" ):
                listener.enterStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStatement" ):
                listener.exitStatement(self)




    def statement(self):

        localctx = BasicParser.StatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_statement)
        try:
            self.state = 55
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [12]:
                self.enterOuterAlt(localctx, 1)
                self.state = 46
                self.letStmt()
                pass
            elif token in [31]:
                self.enterOuterAlt(localctx, 2)
                self.state = 47
                self.opStmt()
                pass
            elif token in [13]:
                self.enterOuterAlt(localctx, 3)
                self.state = 48
                self.printStmt()
                pass
            elif token in [14]:
                self.enterOuterAlt(localctx, 4)
                self.state = 49
                self.inputStmt()
                pass
            elif token in [15]:
                self.enterOuterAlt(localctx, 5)
                self.state = 50
                self.ifStmt()
                pass
            elif token in [17]:
                self.enterOuterAlt(localctx, 6)
                self.state = 51
                self.forStmt()
                pass
            elif token in [20]:
                self.enterOuterAlt(localctx, 7)
                self.state = 52
                self.whileStmt()
                pass
            elif token in [21]:
                self.enterOuterAlt(localctx, 8)
                self.state = 53
                self.repeatStmt()
                pass
            elif token in [23, 24]:
                self.enterOuterAlt(localctx, 9)
                self.state = 54
                self.keyStmt()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LetStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LET_KW(self):
            return self.getToken(BasicParser.LET_KW, 0)

        def ID(self):
            return self.getToken(BasicParser.ID, 0)

        def expression(self):
            return self.getTypedRuleContext(BasicParser.ExpressionContext,0)


        def getRuleIndex(self):
            return BasicParser.RULE_letStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLetStmt" ):
                listener.enterLetStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLetStmt" ):
                listener.exitLetStmt(self)




    def letStmt(self):

        localctx = BasicParser.LetStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_letStmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 57
            self.match(BasicParser.LET_KW)
            self.state = 58
            self.match(BasicParser.ID)
            self.state = 59
            self.match(BasicParser.T__0)
            self.state = 60
            self.expression(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class OpStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(BasicParser.ID, 0)

        def expression(self):
            return self.getTypedRuleContext(BasicParser.ExpressionContext,0)


        def getRuleIndex(self):
            return BasicParser.RULE_opStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOpStmt" ):
                listener.enterOpStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOpStmt" ):
                listener.exitOpStmt(self)




    def opStmt(self):

        localctx = BasicParser.OpStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_opStmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 62
            self.match(BasicParser.ID)
            self.state = 63
            self.match(BasicParser.T__0)
            self.state = 64
            self.expression(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PrintStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def PRINT_KW(self):
            return self.getToken(BasicParser.PRINT_KW, 0)

        def expression(self):
            return self.getTypedRuleContext(BasicParser.ExpressionContext,0)


        def getRuleIndex(self):
            return BasicParser.RULE_printStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrintStmt" ):
                listener.enterPrintStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrintStmt" ):
                listener.exitPrintStmt(self)




    def printStmt(self):

        localctx = BasicParser.PrintStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_printStmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 66
            self.match(BasicParser.PRINT_KW)
            self.state = 67
            self.expression(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InputStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INPUT_KW(self):
            return self.getToken(BasicParser.INPUT_KW, 0)

        def STRING_LITERAL(self):
            return self.getToken(BasicParser.STRING_LITERAL, 0)

        def ID(self):
            return self.getToken(BasicParser.ID, 0)

        def getRuleIndex(self):
            return BasicParser.RULE_inputStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInputStmt" ):
                listener.enterInputStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInputStmt" ):
                listener.exitInputStmt(self)




    def inputStmt(self):

        localctx = BasicParser.InputStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_inputStmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 69
            self.match(BasicParser.INPUT_KW)
            self.state = 70
            self.match(BasicParser.STRING_LITERAL)
            self.state = 71
            self.match(BasicParser.ID)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IfStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IF_KW(self):
            return self.getToken(BasicParser.IF_KW, 0)

        def condition(self):
            return self.getTypedRuleContext(BasicParser.ConditionContext,0)


        def THEN_KW(self):
            return self.getToken(BasicParser.THEN_KW, 0)

        def NEWLINE(self, i:int=None):
            if i is None:
                return self.getTokens(BasicParser.NEWLINE)
            else:
                return self.getToken(BasicParser.NEWLINE, i)

        def END_KW(self):
            return self.getToken(BasicParser.END_KW, 0)

        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(BasicParser.StatementContext)
            else:
                return self.getTypedRuleContext(BasicParser.StatementContext,i)


        def ELSE_KW(self):
            return self.getToken(BasicParser.ELSE_KW, 0)

        def getRuleIndex(self):
            return BasicParser.RULE_ifStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIfStmt" ):
                listener.enterIfStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIfStmt" ):
                listener.exitIfStmt(self)




    def ifStmt(self):

        localctx = BasicParser.IfStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_ifStmt)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 73
            self.match(BasicParser.IF_KW)
            self.state = 74
            self.condition()
            self.state = 75
            self.match(BasicParser.THEN_KW)
            self.state = 76
            self.match(BasicParser.NEWLINE)
            self.state = 82
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 2175987712) != 0):
                self.state = 77
                self.statement()
                self.state = 78
                self.match(BasicParser.NEWLINE)
                self.state = 84
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 95
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==16:
                self.state = 85
                self.match(BasicParser.ELSE_KW)
                self.state = 86
                self.match(BasicParser.NEWLINE)
                self.state = 92
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while (((_la) & ~0x3f) == 0 and ((1 << _la) & 2175987712) != 0):
                    self.state = 87
                    self.statement()
                    self.state = 88
                    self.match(BasicParser.NEWLINE)
                    self.state = 94
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)



            self.state = 97
            self.match(BasicParser.END_KW)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ForStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def FOR_KW(self):
            return self.getToken(BasicParser.FOR_KW, 0)

        def ID(self):
            return self.getToken(BasicParser.ID, 0)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(BasicParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(BasicParser.ExpressionContext,i)


        def TO_KW(self):
            return self.getToken(BasicParser.TO_KW, 0)

        def NEWLINE(self, i:int=None):
            if i is None:
                return self.getTokens(BasicParser.NEWLINE)
            else:
                return self.getToken(BasicParser.NEWLINE, i)

        def NEXT_KW(self):
            return self.getToken(BasicParser.NEXT_KW, 0)

        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(BasicParser.StatementContext)
            else:
                return self.getTypedRuleContext(BasicParser.StatementContext,i)


        def getRuleIndex(self):
            return BasicParser.RULE_forStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterForStmt" ):
                listener.enterForStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitForStmt" ):
                listener.exitForStmt(self)




    def forStmt(self):

        localctx = BasicParser.ForStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_forStmt)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 99
            self.match(BasicParser.FOR_KW)
            self.state = 100
            self.match(BasicParser.ID)
            self.state = 101
            self.match(BasicParser.T__0)
            self.state = 102
            self.expression(0)
            self.state = 103
            self.match(BasicParser.TO_KW)
            self.state = 104
            self.expression(0)
            self.state = 105
            self.match(BasicParser.NEWLINE)
            self.state = 111
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 2175987712) != 0):
                self.state = 106
                self.statement()
                self.state = 107
                self.match(BasicParser.NEWLINE)
                self.state = 113
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 114
            self.match(BasicParser.NEXT_KW)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class WhileStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def WHILE_KW(self):
            return self.getToken(BasicParser.WHILE_KW, 0)

        def condition(self):
            return self.getTypedRuleContext(BasicParser.ConditionContext,0)


        def NEWLINE(self, i:int=None):
            if i is None:
                return self.getTokens(BasicParser.NEWLINE)
            else:
                return self.getToken(BasicParser.NEWLINE, i)

        def END_KW(self):
            return self.getToken(BasicParser.END_KW, 0)

        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(BasicParser.StatementContext)
            else:
                return self.getTypedRuleContext(BasicParser.StatementContext,i)


        def getRuleIndex(self):
            return BasicParser.RULE_whileStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterWhileStmt" ):
                listener.enterWhileStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitWhileStmt" ):
                listener.exitWhileStmt(self)




    def whileStmt(self):

        localctx = BasicParser.WhileStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_whileStmt)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 116
            self.match(BasicParser.WHILE_KW)
            self.state = 117
            self.condition()
            self.state = 118
            self.match(BasicParser.NEWLINE)
            self.state = 124
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 2175987712) != 0):
                self.state = 119
                self.statement()
                self.state = 120
                self.match(BasicParser.NEWLINE)
                self.state = 126
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 127
            self.match(BasicParser.END_KW)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RepeatStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def REPEAT_KW(self):
            return self.getToken(BasicParser.REPEAT_KW, 0)

        def NEWLINE(self, i:int=None):
            if i is None:
                return self.getTokens(BasicParser.NEWLINE)
            else:
                return self.getToken(BasicParser.NEWLINE, i)

        def UNTIL_KW(self):
            return self.getToken(BasicParser.UNTIL_KW, 0)

        def condition(self):
            return self.getTypedRuleContext(BasicParser.ConditionContext,0)


        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(BasicParser.StatementContext)
            else:
                return self.getTypedRuleContext(BasicParser.StatementContext,i)


        def getRuleIndex(self):
            return BasicParser.RULE_repeatStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRepeatStmt" ):
                listener.enterRepeatStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRepeatStmt" ):
                listener.exitRepeatStmt(self)




    def repeatStmt(self):

        localctx = BasicParser.RepeatStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_repeatStmt)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 129
            self.match(BasicParser.REPEAT_KW)
            self.state = 130
            self.match(BasicParser.NEWLINE)
            self.state = 136
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 2175987712) != 0):
                self.state = 131
                self.statement()
                self.state = 132
                self.match(BasicParser.NEWLINE)
                self.state = 138
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 139
            self.match(BasicParser.UNTIL_KW)
            self.state = 140
            self.condition()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class KeyStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CONTINUE_KW(self):
            return self.getToken(BasicParser.CONTINUE_KW, 0)

        def EXIT_KW(self):
            return self.getToken(BasicParser.EXIT_KW, 0)

        def getRuleIndex(self):
            return BasicParser.RULE_keyStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKeyStmt" ):
                listener.enterKeyStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKeyStmt" ):
                listener.exitKeyStmt(self)




    def keyStmt(self):

        localctx = BasicParser.KeyStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_keyStmt)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 142
            _la = self._input.LA(1)
            if not(_la==23 or _la==24):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConditionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(BasicParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(BasicParser.ExpressionContext,i)


        def comparisonOp(self):
            return self.getTypedRuleContext(BasicParser.ComparisonOpContext,0)


        def getRuleIndex(self):
            return BasicParser.RULE_condition

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCondition" ):
                listener.enterCondition(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCondition" ):
                listener.exitCondition(self)




    def condition(self):

        localctx = BasicParser.ConditionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_condition)
        try:
            self.state = 149
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,10,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 144
                self.expression(0)
                self.state = 145
                self.comparisonOp()
                self.state = 146
                self.expression(0)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 148
                self.expression(0)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ComparisonOpContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return BasicParser.RULE_comparisonOp

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComparisonOp" ):
                listener.enterComparisonOp(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComparisonOp" ):
                listener.exitComparisonOp(self)




    def comparisonOp(self):

        localctx = BasicParser.ComparisonOpContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_comparisonOp)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 151
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 62) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(BasicParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(BasicParser.ExpressionContext,i)


        def functionCall(self):
            return self.getTypedRuleContext(BasicParser.FunctionCallContext,0)


        def NUMBER(self):
            return self.getToken(BasicParser.NUMBER, 0)

        def STRING_LITERAL(self):
            return self.getToken(BasicParser.STRING_LITERAL, 0)

        def ID(self):
            return self.getToken(BasicParser.ID, 0)

        def MOD_KW(self):
            return self.getToken(BasicParser.MOD_KW, 0)

        def getRuleIndex(self):
            return BasicParser.RULE_expression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpression" ):
                listener.enterExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpression" ):
                listener.exitExpression(self)



    def expression(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = BasicParser.ExpressionContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 26
        self.enterRecursionRule(localctx, 26, self.RULE_expression, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 162
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [10]:
                self.state = 154
                self.match(BasicParser.T__9)
                self.state = 155
                self.expression(0)
                self.state = 156
                self.match(BasicParser.T__10)
                pass
            elif token in [28, 29, 30]:
                self.state = 158
                self.functionCall()
                pass
            elif token in [32]:
                self.state = 159
                self.match(BasicParser.NUMBER)
                pass
            elif token in [33]:
                self.state = 160
                self.match(BasicParser.STRING_LITERAL)
                pass
            elif token in [31]:
                self.state = 161
                self.match(BasicParser.ID)
                pass
            else:
                raise NoViableAltException(self)

            self._ctx.stop = self._input.LT(-1)
            self.state = 169
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,12,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    localctx = BasicParser.ExpressionContext(self, _parentctx, _parentState)
                    self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                    self.state = 164
                    if not self.precpred(self._ctx, 6):
                        from antlr4.error.Errors import FailedPredicateException
                        raise FailedPredicateException(self, "self.precpred(self._ctx, 6)")
                    self.state = 165
                    _la = self._input.LA(1)
                    if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 134218688) != 0)):
                        self._errHandler.recoverInline(self)
                    else:
                        self._errHandler.reportMatch(self)
                        self.consume()
                    self.state = 166
                    self.expression(7) 
                self.state = 171
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,12,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class FunctionCallContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def VAL_KW(self):
            return self.getToken(BasicParser.VAL_KW, 0)

        def expression(self):
            return self.getTypedRuleContext(BasicParser.ExpressionContext,0)


        def LEN_KW(self):
            return self.getToken(BasicParser.LEN_KW, 0)

        def ISNAN_KW(self):
            return self.getToken(BasicParser.ISNAN_KW, 0)

        def getRuleIndex(self):
            return BasicParser.RULE_functionCall

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFunctionCall" ):
                listener.enterFunctionCall(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFunctionCall" ):
                listener.exitFunctionCall(self)




    def functionCall(self):

        localctx = BasicParser.FunctionCallContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_functionCall)
        try:
            self.state = 187
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [28]:
                self.enterOuterAlt(localctx, 1)
                self.state = 172
                self.match(BasicParser.VAL_KW)
                self.state = 173
                self.match(BasicParser.T__9)
                self.state = 174
                self.expression(0)
                self.state = 175
                self.match(BasicParser.T__10)
                pass
            elif token in [29]:
                self.enterOuterAlt(localctx, 2)
                self.state = 177
                self.match(BasicParser.LEN_KW)
                self.state = 178
                self.match(BasicParser.T__9)
                self.state = 179
                self.expression(0)
                self.state = 180
                self.match(BasicParser.T__10)
                pass
            elif token in [30]:
                self.enterOuterAlt(localctx, 3)
                self.state = 182
                self.match(BasicParser.ISNAN_KW)
                self.state = 183
                self.match(BasicParser.T__9)
                self.state = 184
                self.expression(0)
                self.state = 185
                self.match(BasicParser.T__10)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[13] = self.expression_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def expression_sempred(self, localctx:ExpressionContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 6)
         




